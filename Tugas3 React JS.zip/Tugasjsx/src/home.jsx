import React from "react";
import books from "./books";
import "./App.css";

function Home() {
  return (
    <div className="container">
      <h1>Daftar Buku</h1>
      <ul>
        {books.map((book) => (
          <li key={book.id}>
            <strong>{book.title}</strong> - {book.author} (Rp {book.price})
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Home;

const books = [
  { id: 1, title: "Cara Sukses Timothy Ronald", author: "Tamrin", price: 75000 },
  { id: 2, title: "Cara Akting Seperti Lord Suroso", author: "Budi Santoso", price: 68000 },
  { id: 3, title: "Tutorial Mendapatkan Fineshyt", author: "Jupri", price: 85000 },
  { id: 4, title: "Menaikan Rank Valorant", author: "Tenz", price: 72000 },
  { id: 5, title: "Qoute Mario Bros", author: "Eka Gustiwana", price: 90000 },
  { id: 6, title: "Kamus Ngawi Terkenal", author: "Mas Narji", price: 120000 },
  { id: 7, title: "Model Rambut Ngawi", author: "Mas Rusdi", price: 80000 },
  { id: 8, title: "Kode Jika Seorang Muak Di Pinjam Uang", author: "Robert Downey Junior", price: 150000 },
  { id: 9, title: "Cara Meruntuhkan Pemerintahan", author: "Pace Kobo", price: 135000 },
];

export default books;

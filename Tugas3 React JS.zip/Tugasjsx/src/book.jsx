import React, { useState } from "react";
import booksData from "./books";
import "./App.css";

function Book() {
  const [books, setBooks] = useState(booksData);
  const [newBook, setNewBook] = useState({
    title: "",
    author: "",
    price: "",
  });

  const handleChange = (e) => {
    setNewBook({
      ...newBook,
      [e.target.name]: e.target.value,
    });
  };

  const addBook = () => {
    if (!newBook.title || !newBook.author || !newBook.price) return;

    const newId = books.length + 1;
    setBooks([
      ...books,
      {
        id: newId,
        title: newBook.title,
        author: newBook.author,
        price: newBook.price,
      },
    ]);
    setNewBook({ title: "", author: "", price: "" });
  };

  return (
    <div className="container">
      <h1>Halaman Book</h1>
      <ul>
        {books.map((book) => (
          <li key={book.id}>
            <strong>{book.title}</strong> - {book.author} (Rp {book.price})
          </li>
        ))}
      </ul>

      <h2>Tambah Buku Baru</h2>
      <input
        type="text"
        name="title"
        placeholder="Judul Buku"
        value={newBook.title}
        onChange={handleChange}
      />
      <br />
      <input
        type="text"
        name="author"
        placeholder="Penulis"
        value={newBook.author}
        onChange={handleChange}
      />
      <br />
      <input
        type="number"
        name="price"
        placeholder="Harga"
        value={newBook.price}
        onChange={handleChange}
      />
      <br />
      <button onClick={addBook}>Tambah Buku</button>
    </div>
  );
}

export default Book;

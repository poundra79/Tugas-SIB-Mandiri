<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Author;

class AuthorSeeder extends Seeder
{
    public function run(): void
    {
        Author::insert([
            ['name' => 'Tere Liye', 'bio' => 'Penulis novel populer di Indonesia'],
            ['name' => 'Andrea Hirata', 'bio' => 'Penulis Laskar Pelangi'],
            ['name' => 'Dewi Lestari', 'bio' => 'Penulis dan musisi Indonesia'],
            ['name' => 'Ahmad Fuadi', 'bio' => 'Penulis Negeri 5 Menara'],
            ['name' => 'Habiburrahman El Shirazy', 'bio' => 'Penulis Ayat-Ayat Cinta'],
        ]);
    }
}

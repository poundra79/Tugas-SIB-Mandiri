function Team() {
  const members = [
    { name: "Poundra Adiyatma", role: "Frontend Developer", img: "https://i.pravatar.cc/150?img=1" },
    { name: "Andika Syahputra", role: "Backend Developer", img: "https://i.pravatar.cc/150?img=2" },
    { name: "Liam Gallagher", role: "UI/UX Designer", img: "https://i.pravatar.cc/150?img=3" },
  ];

  return (
    <div className="container-fluid mt-5">
      <h2 className="text-center mb-4">Our Team</h2>
      <div className="row">
        {members.map((m, i) => (
          <div key={i} className="col-md-4 mb-4">
            <div className="card shadow h-100 text-center">
              <img src={m.img} className="card-img-top" alt={m.name} />
              <div className="card-body">
                <h5 className="card-title">{m.name}</h5>
                <p className="card-text">{m.role}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Team;

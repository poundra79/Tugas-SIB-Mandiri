function Contact() {
  return (
    <div className="container mt-5">
      <h2 className="text-center mb-4">Contact Us</h2>
      <div className="row">
        <div className="col-md-6">
          <form className="p-4 border rounded shadow bg-light">
            <div className="mb-3">
              <label className="form-label">Nama</label>
              <input type="text" className="form-control" placeholder="Masukkan nama Anda" />
            </div>
            <div className="mb-3">
              <label className="form-label">Email</label>
              <input type="email" className="form-control" placeholder="Masukkan email Anda" />
            </div>
            <div className="mb-3">
              <label className="form-label">Pesan</label>
              <textarea className="form-control" rows="4" placeholder="Tulis pesan Anda di sini"></textarea>
            </div>
            <button type="submit" className="btn btn-primary">Kirim</button>
          </form>
        </div>
        <div className="col-md-6 d-flex flex-column justify-content-center">
          <h5>Alamat</h5>
          <p>Jl. Teknologi No. 123, Jakarta</p>
          <h5>Email</h5>
          <p>info@website.com</p>
          <h5>Telepon</h5>
          <p>+62 812-3456-7890</p>
        </div>
      </div>
    </div>
  );
}

export default Contact;

<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GenreController;
use App\Http\Controllers\AuthorController;

// Halaman utama (bawaan Laravel)
Route::get('/', function () {
    return view('welcome');
});

// Route untuk Genre
Route::get('/genre', [GenreController::class, 'index'])->name('genre.index');

// Route untuk Author
Route::get('/author', [AuthorController::class, 'index'])->name('author.index');

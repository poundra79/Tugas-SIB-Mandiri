<?php

namespace App\Models;

class Author
{
    public static function getAllAuthors()
    {
        return [
            ['id' => 1, 'name' => 'J.K. Rowling', 'country' => 'UK'],
            ['id' => 2, 'name' => 'George R.R. Martin', 'country' => 'USA'],
            ['id' => 3, 'name' => 'Agatha Christie', 'country' => 'UK'],
            ['id' => 4, 'name' => 'Stephen King', 'country' => 'USA'],
            ['id' => 5, 'name' => 'Haruki Murakami', 'country' => 'Japan'],
        ];
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AuthorController extends Controller
{
    public function index()
    {
        $authors = [
            ['id' => 1, 'name' => 'J.K. Rowling', 'country' => 'Inggris'],
            ['id' => 2, 'name' => 'George R.R. Martin', 'country' => 'Amerika Serikat'],
            ['id' => 3, 'name' => 'Haruki Murakami', 'country' => 'Jepang'],
            ['id' => 4, 'name' => 'Tere Liye', 'country' => 'Indonesia'],
            ['id' => 5, 'name' => 'Stephen King', 'country' => 'Amerika Serikat'],
        ];

        return view('author', compact('authors'));
    }
}

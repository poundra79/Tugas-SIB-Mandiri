<!DOCTYPE html>
<html>
<head>
    <title>Data Genre</title>
</head>
<body>
    <h1>Daftar Genre Buku</h1>
    <ul>
        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($genre['id']); ?> - <?php echo e($genre['name']); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH C:\Users\MyBook Hype AMD\Pictures\SIB Mandiri\mvc-simple\resources\views/genre.blade.php ENDPATH**/ ?>
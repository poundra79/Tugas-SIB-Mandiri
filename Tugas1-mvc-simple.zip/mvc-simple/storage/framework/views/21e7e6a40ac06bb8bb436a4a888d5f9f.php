<!DOCTYPE html>
<html>
<head>
    <title>Data Author</title>
</head>
<body>
    <h1>Daftar Penulis Buku</h1>
    <ul>
        <?php $__currentLoopData = $authors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $author): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li><?php echo e($author['id']); ?> - <?php echo e($author['name']); ?> (<?php echo e($author['country']); ?>)</li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html>
<?php /**PATH C:\Users\MyBook Hype AMD\Pictures\SIB Mandiri\mvc-simple\resources\views/author.blade.php ENDPATH**/ ?>
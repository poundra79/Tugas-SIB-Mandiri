<!DOCTYPE html>
<html>
<head>
    <title>Data Author</title>
</head>
<body>
    <h1>Daftar Penulis Buku</h1>
    <ul>
        @foreach ($authors as $author)
            <li>{{ $author['id'] }} - {{ $author['name'] }} ({{ $author['country'] }})</li>
        @endforeach
    </ul>
</body>
</html>

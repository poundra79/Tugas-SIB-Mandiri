<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h1><?php echo e($book->title); ?></h1>
    <p><strong>Genre:</strong> <?php echo e($book->genre); ?></p>
    <p><strong>Penulis:</strong> <?php echo e($book->author->name); ?></p>
    <p><strong>Bio Penulis:</strong> <?php echo e($book->author->bio); ?></p>

    <a href="/books" class="btn btn-secondary">Kembali</a>
</body>
</html>
<?php /**PATH C:\Users\MyBook Hype AMD\Pictures\SIB Mandiri\booksales-api-laravel\resources\views/books/show.blade.php ENDPATH**/ ?>
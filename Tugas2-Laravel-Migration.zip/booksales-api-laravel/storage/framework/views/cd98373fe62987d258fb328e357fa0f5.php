<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Daftar Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h1 class="mb-3">📚 Daftar Buku</h1>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Judul</th>
                <th>Genre</th>
                <th>Penulis</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($book->title); ?></td>
                    <td><?php echo e($book->genre); ?></td>
                    <td><?php echo e($book->author->name); ?></td>
                    <td>
                        <a href="/books/<?php echo e($book->id); ?>" class="btn btn-sm btn-primary">Detail</a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\Users\MyBook Hype AMD\Pictures\SIB Mandiri\booksales-api-laravel\resources\views/books/index.blade.php ENDPATH**/ ?>
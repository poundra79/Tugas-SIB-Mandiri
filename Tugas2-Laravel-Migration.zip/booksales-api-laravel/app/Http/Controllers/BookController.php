<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;

class BookController extends Controller
{
    // Tampilkan semua buku
    public function index()
    {
        // Ambil semua data buku beserta author-nya
        $books = Book::with('author')->get();

        return view('books.index', compact('books'));
    }

    // Menampilkan detail satu buku
    public function show($id)
    {
        $book = Book::with('author')->findOrFail($id);

        return view('books.show', compact('book'));
    }
}

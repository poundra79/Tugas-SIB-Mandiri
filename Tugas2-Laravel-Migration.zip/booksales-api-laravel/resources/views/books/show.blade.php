<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Detail Buku</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
    <h1>{{ $book->title }}</h1>
    <p><strong>Genre:</strong> {{ $book->genre }}</p>
    <p><strong>Penulis:</strong> {{ $book->author->name }}</p>
    <p><strong>Bio Penulis:</strong> {{ $book->author->bio }}</p>

    <a href="/books" class="btn btn-secondary">Kembali</a>
</body>
</html>

<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
    use HasFactory;

    // Kolom yang boleh diisi massal
    protected $fillable = ['title', 'genre_id', 'author_id'];

    /**
     * Relasi ke Author
     * Satu buku dimiliki oleh satu author
     */
    public function author()
    {
        return $this->belongsTo(Author::class);
    }

    /**
     * Relasi ke Genre
     * Satu buku memiliki satu genre
     */
    public function genre()
    {
        return $this->belongsTo(Genre::class);
    }
}

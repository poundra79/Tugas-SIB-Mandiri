<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Author extends Model
{
    use HasFactory;

    /**
     * Nama tabel
     */
    protected $table = 'authors';

    /**
     * Kolom yang bisa diisi secara massal
     */
    protected $fillable = [
        'name',
        'bio',
    ];

    /**
     * Relasi ke Book
     * Satu penulis bisa punya banyak buku
     */
    public function books()
    {
        return $this->hasMany(Book::class);
    }
}

<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GenreController;
use App\Http\Controllers\AuthorController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
*/

Route::get('/genres', [GenreController::class, 'index']);      // GET all
Route::get('/genres/{id}', [GenreController::class, 'show']);  // GET by ID
Route::post('/genres', [GenreController::class, 'store']);     // POST create
Route::put('/genres/{id}', [GenreController::class, 'update']); // PUT update
Route::delete('/genres/{id}', [GenreController::class, 'destroy']); // DELETE

// Author routes
Route::get('/authors', [AuthorController::class, 'index']);
Route::get('/authors/{id}', [AuthorController::class, 'show']);
Route::post('/authors', [AuthorController::class, 'store']);
Route::put('/authors/{id}', [AuthorController::class, 'update']);
Route::delete('/authors/{id}', [AuthorController::class, 'destroy']);

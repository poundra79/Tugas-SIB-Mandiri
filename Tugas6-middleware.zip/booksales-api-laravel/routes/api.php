<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\GenreController;
use App\Http\Controllers\AuthorController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\TransactionController;
use App\Http\Controllers\BookController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
| Endpoint REST API untuk aplikasi BookSales
| - Public routes: dapat diakses tanpa autentikasi
| - Admin routes: hanya untuk admin (middleware: admin)
|--------------------------------------------------------------------------
*/


// =========================================================
// 🔓 PUBLIC ROUTES (Semua pengguna, tanpa autentikasi)
// =========================================================

// Genre - hanya Read
Route::get('/genres', [GenreController::class, 'index']);
Route::get('/genres/{id}', [GenreController::class, 'show']);

// Author - hanya Read
Route::get('/authors', [AuthorController::class, 'index']);
Route::get('/authors/{id}', [AuthorController::class, 'show']);

// Book - bisa diakses publik juga
Route::get('/books', [BookController::class, 'index']);
Route::get('/books/{id}', [BookController::class, 'show']);
Route::get('/books/genre/{genre_id}', [BookController::class, 'getByGenre']);
Route::get('/books/author/{author_id}', [BookController::class, 'getByAuthor']);
Route::get('/books/search/{keyword}', [BookController::class, 'search']);



// =========================================================
// 🔒 ADMIN-ONLY ROUTES (dengan middleware 'admin')
// =========================================================
Route::middleware(['admin'])->group(function () {

    // Genre - CRUD (Create, Update, Delete hanya admin)
    Route::post('/genres', [GenreController::class, 'store']);
    Route::put('/genres/{id}', [GenreController::class, 'update']);
    Route::delete('/genres/{id}', [GenreController::class, 'destroy']);

    // Author - CRUD
    Route::post('/authors', [AuthorController::class, 'store']);
    Route::put('/authors/{id}', [AuthorController::class, 'update']);
    Route::delete('/authors/{id}', [AuthorController::class, 'destroy']);

    // Book - CRUD
    Route::post('/books', [BookController::class, 'store']);
    Route::put('/books/{id}', [BookController::class, 'update']);
    Route::delete('/books/{id}', [BookController::class, 'destroy']);

    // User - CRUD dan relasi transaksi
    Route::apiResource('users', UserController::class);
    Route::get('/users/{id}/transactions', [UserController::class, 'transactions']);

    // Transaction - CRUD dan filter by user
    Route::apiResource('transactions', TransactionController::class);
    Route::get('/transactions/user/{user_id}', [TransactionController::class, 'getByUser']);
});

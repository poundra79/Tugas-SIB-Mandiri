<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class AdminMiddleware
{
    /**
     * Handle an incoming request.
     *
     * Cek apakah user yang sedang login memiliki role 'admin'.
     * Jika bukan admin, maka kembalikan respon "Access Denied".
     */
    public function handle(Request $request, Closure $next): Response
    {
        // Pastikan user sudah login dan punya role
        $user = $request->user();

        if (!$user) {
            return response()->json([
                'message' => 'Unauthorized. Please log in first.'
            ], 401);
        }

        // Cek apakah role-nya admin
        if ($user->role !== 'admin') {
            return response()->json([
                'message' => 'Access denied. Admins only.'
            ], 403);
        }

        // Kalau admin, lanjut ke request berikutnya
        return $next($request);
    }
}

<?php

namespace App\Http\Controllers;

use App\Models\Book;
use Illuminate\Http\Request;

class BookController extends Controller
{
    // GET /api/books
    public function index()
    {
        $books = Book::with(['author', 'genre'])->get();
        return response()->json($books);
    }

    // GET /api/books/{id}
    public function show($id)
    {
        $book = Book::with(['author', 'genre'])->findOrFail($id);
        return response()->json($book);
    }

    // POST /api/books
    public function store(Request $request)
    {
        $validated = $request->validate([
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'price' => 'required|numeric',
            'stock' => 'required|integer',
            'cover_photo' => 'nullable|string',
            'genre_id' => 'required|exists:genres,id',
            'author_id' => 'required|exists:authors,id',
        ]);

        $book = Book::create($validated);

        return response()->json([
            'message' => 'Book created successfully',
            'data' => $book
        ], 201);
    }

    // PUT /api/books/{id}
    public function update(Request $request, $id)
    {
        $book = Book::findOrFail($id);

        $validated = $request->validate([
            'title' => 'sometimes|string|max:255',
            'description' => 'nullable|string',
            'price' => 'sometimes|numeric',
            'stock' => 'sometimes|integer',
            'cover_photo' => 'nullable|string',
            'genre_id' => 'sometimes|exists:genres,id',
            'author_id' => 'sometimes|exists:authors,id',
        ]);

        $book->update($validated);

        return response()->json([
            'message' => 'Book updated successfully',
            'data' => $book
        ]);
    }

    // DELETE /api/books/{id}
    public function destroy($id)
    {
        $book = Book::findOrFail($id);
        $book->delete();

        return response()->json(['message' => 'Book deleted successfully']);
    }

    // 🔹 GET /api/books/genre/{genre_id}
    public function getByGenre($genre_id)
    {
        $books = Book::where('genre_id', $genre_id)
                    ->with(['author', 'genre'])
                    ->get();

        if ($books->isEmpty()) {
            return response()->json(['message' => 'No books found for this genre'], 404);
        }

        return response()->json($books);
    }

    // 🔹 GET /api/books/author/{author_id}
    public function getByAuthor($author_id)
    {
        $books = Book::where('author_id', $author_id)
                    ->with(['author', 'genre'])
                    ->get();

        if ($books->isEmpty()) {
            return response()->json(['message' => 'No books found for this author'], 404);
        }

        return response()->json($books);
    }

    // 🔹 GET /api/books/search/{keyword}
    public function search($keyword)
    {
        $books = Book::where('title', 'like', "%{$keyword}%")
                    ->orWhere('description', 'like', "%{$keyword}%")
                    ->with(['author', 'genre'])
                    ->get();

        if ($books->isEmpty()) {
            return response()->json(['message' => 'No books found for this keyword'], 404);
        }

        return response()->json($books);
    }
}

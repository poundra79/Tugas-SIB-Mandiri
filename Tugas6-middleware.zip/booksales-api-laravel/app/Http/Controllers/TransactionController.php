<?php

namespace App\Http\Controllers;

use App\Models\Transaction;
use Illuminate\Http\Request;

class TransactionController extends Controller
{
    // GET /api/transactions
    public function index()
    {
        $transactions = Transaction::with(['user', 'book'])->get();
        return response()->json($transactions);
    }

    // GET /api/transactions/{id}
    public function show($id)
    {
        $transaction = Transaction::with(['user', 'book'])->findOrFail($id);
        return response()->json($transaction);
    }

    // POST /api/transactions
    public function store(Request $request)
    {
        $validated = $request->validate([
            'customer_id' => 'required|exists:users,id',
            'book_id' => 'required|exists:books,id',
            'total_amount' => 'required|numeric|min:0',
        ]);

        $transaction = Transaction::create([
            'order_number' => 'ORD-' . strtoupper(uniqid()),
            'customer_id' => $validated['customer_id'],
            'book_id' => $validated['book_id'],
            'total_amount' => $validated['total_amount'],
        ]);

        return response()->json([
            'message' => 'Transaction created successfully',
            'data' => $transaction
        ], 201);
    }

    // PUT /api/transactions/{id}
    public function update(Request $request, $id)
    {
        $transaction = Transaction::findOrFail($id);

        $validated = $request->validate([
            'book_id' => 'sometimes|exists:books,id',
            'total_amount' => 'sometimes|numeric|min:0',
        ]);

        $transaction->update($validated);

        return response()->json([
            'message' => 'Transaction updated successfully',
            'data' => $transaction
        ]);
    }

    // DELETE /api/transactions/{id}
    public function destroy($id)
    {
        $transaction = Transaction::findOrFail($id);
        $transaction->delete();

        return response()->json(['message' => 'Transaction deleted successfully']);
    }

    // 🔹 GET /api/transactions/user/{user_id}
    public function getByUser($user_id)
    {
        $transactions = Transaction::where('customer_id', $user_id)
            ->with(['book', 'user'])
            ->get();

        if ($transactions->isEmpty()) {
            return response()->json(['message' => 'No transactions found for this user'], 404);
        }

        return response()->json($transactions);
    }
}

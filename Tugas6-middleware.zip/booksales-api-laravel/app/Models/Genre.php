<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Genre extends Model
{
    use HasFactory;

    /**
     * Nama tabel (pastikan sesuai di database)
     */
    protected $table = 'genres';

    /**
     * Kolom yang boleh diisi secara massal
     */
    protected $fillable = [
        'name',
        'description',
    ];

    /**
     * Relasi ke Book
     * Satu genre bisa memiliki banyak buku
     */
    public function books()
    {
        return $this->hasMany(Book::class);
    }
}

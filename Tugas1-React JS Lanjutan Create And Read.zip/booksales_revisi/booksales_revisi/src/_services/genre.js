import API from "../_api"

export const  getGenres = async () => {
    const { data } = API.get("/genres")
    return data.data
}

export const createBook = async (data) => {
    try {
        const response = await API.post("/books",data)
        return response.data
    }   catch (error) {
        console.log(error);
        throw error
    }

}

import API from "../_api"

export const  getBooks = async () => {
    const { data } = API.get("/books")
    return data.data
}
import Hero from "../components/hero";
import Testimonial from "../components/testimonial";
import Navbar from "../components/navbar";
export default function Home() {
    return(
        <>
            <Hero />
            <Testimonial/>
        </>
    );
}
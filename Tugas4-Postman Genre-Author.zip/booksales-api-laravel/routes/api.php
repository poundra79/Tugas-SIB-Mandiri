<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\BookController;
use App\Http\Controllers\AuthorController;
use App\Http\Controllers\GenreController;

// ========================
// 📚 ROUTE UNTUK BOOKS
// ========================
Route::get('/books', [BookController::class, 'index']);
Route::get('/books/{id}', [BookController::class, 'show']);

// ========================
// ✍️ ROUTE UNTUK AUTHORS
// ========================
Route::get('/authors', [AuthorController::class, 'index']);
Route::get('/authors/{id}', [AuthorController::class, 'show']);
Route::post('/authors', [AuthorController::class, 'store']); // ✅ Create author baru

// ========================
// 🎭 ROUTE UNTUK GENRES
// ========================
Route::get('/genres', [GenreController::class, 'index']);   // ✅ Read all genre
Route::get('/genres/{id}', [GenreController::class, 'show']); // ✅ Read by ID (optional)
Route::post('/genres', [GenreController::class, 'store']);  // ✅ Create genre baru

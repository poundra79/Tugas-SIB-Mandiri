<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Book;

class BookSeeder extends Seeder
{
    public function run(): void
    {
        Book::insert([
            ['title' => 'Bumi', 'genre' => 'Fantasi', 'author_id' => 1],
            ['title' => 'Laskar Pelangi', 'genre' => 'Drama', 'author_id' => 2],
            ['title' => 'Supernova', 'genre' => 'Fiksi Ilmiah', 'author_id' => 3],
            ['title' => 'Negeri 5 Menara', 'genre' => 'Inspiratif', 'author_id' => 4],
            ['title' => 'Ayat-Ayat Cinta', 'genre' => 'Romantis', 'author_id' => 5],
        ]);
    }
}

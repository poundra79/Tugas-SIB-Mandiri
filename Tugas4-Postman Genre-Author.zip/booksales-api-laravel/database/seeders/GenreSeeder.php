<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Genre;

class GenreSeeder extends Seeder
{
    public function run(): void
    {
        Genre::insert([
            ['name' => 'Fiksi'],
            ['name' => 'Drama'],
            ['name' => 'Religi'],
            ['name' => 'Motivasi'],
            ['name' => 'Inspirasi'],
        ]);
    }
}

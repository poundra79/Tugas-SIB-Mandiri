function Team() {
  return (
    <div className="page-container">
      <h1 className="page-title">Tim Kami</h1>
      <p className="page-text">
        Berikut adalah daftar anggota tim yang bekerja di proyek ini.
      </p>

      <div className="row mt-4">
        <div className="col-md-4 mb-4">
          <div className="card shadow p-3">
            <img
              src="https://picsum.photos/200/200?random=1"
              alt="Anggota 1"
              className="img-fluid rounded-circle mb-3"
            />
            <h5>Anggota 1</h5>
            <p className="page-text">Frontend Developer</p>
          </div>
        </div>
        <div className="col-md-4 mb-4">
          <div className="card shadow p-3">
            <img
              src="https://picsum.photos/200/200?random=2"
              alt="Anggota 2"
              className="img-fluid rounded-circle mb-3"
            />
            <h5>Anggota 2</h5>
            <p className="page-text">Backend Developer</p>
          </div>
        </div>
        <div className="col-md-4 mb-4">
          <div className="card shadow p-3">
            <img
              src="https://picsum.photos/200/200?random=3"
              alt="Anggota 3"
              className="img-fluid rounded-circle mb-3"
            />
            <h5>Anggota 3</h5>
            <p className="page-text">UI/UX Designer</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Team;

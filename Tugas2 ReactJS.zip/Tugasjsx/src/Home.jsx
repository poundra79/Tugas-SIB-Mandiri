function Home() {
  return (
    <div className="page-container">
      <div className="row align-items-center">
        <div className="col-md-6">
          <h1 className="page-title">Selamat Datang di Website Kami</h1>
          <p className="page-text">
            Website ini dibuat menggunakan ReactJS dan Bootstrap. Silakan jelajahi halaman Team dan Contact untuk mengenal lebih jauh.
          </p>
        </div>
        <div className="col-md-6 mt-4 mt-md-0">
          <img
            src="https://picsum.photos/500/300"
            alt="Banner"
            className="img-fluid rounded shadow"
          />
        </div>
      </div>
    </div>
  );
}

export default Home;

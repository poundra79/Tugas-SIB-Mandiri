import { Link } from "react-router-dom";

export default function Footer() {
  return (
    <>
      <footer className="mt-auto border-t-2 bg-white dark:bg-gray-800">
        <div className="max-w-screen container py-8 px-2">
          <div className="flex flex-col items-center justify-center">
            <ul className="flex flex-wrap justify-center items-center gap-x-6 gap-y-3 mb-6 text-gray-900 dark:text-white">
              <li>
                <Link to={"#"} className="hover:underline text-sm">
                  About
                </Link>
              </li>
            <li>
              <Link to="#" className="hover:underline text-sm">
                Premium
              </Link>
            </li>
            <li>
              <Link to="#" className="hover:underline text-sm">
                Campaigns
              </Link>
            </li>
            <li>
              <Link to="#" className="hover:underline text-sm">
                Blog
              </Link>
            </li>
            <li>
              <Link to="#" className="hover:underline text-sm">
                Affiliate Program
              </Link>
            </li>
            <li>
              <Link to="#" className="hover:underline text-sm">
                FAQs
              </Link>
            </li>
            <li>
              <Link to="#" className="hover:underline text-sm">
                Contact
              </Link>
            </li>
          </ul>
          <span className="text-sm text-gray-500 dark:text-gray-400">
            © <Link to="#" className="hover:underline">2025</Link>. All Rights Reserved.
          </span>
          </div>
        </div>
      </footer>
    </>
  );
}
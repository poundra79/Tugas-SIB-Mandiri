import { Outlet } from "react-router-dom";
import { Link } from "react-router-dom";

export default function AdminLayout() {
  return (
    <div className="antialiased bg-gray-50 dark:bg-gray-900 min-h-screen">
      {/* ======== Navbar ======== */}
      <nav className="fixed top-0 left-0 right-0 z-50 bg-white border-b border-gray-200 dark:bg-gray-800 dark:border-gray-700">
        <div className="max-w-screen mx-auto px-6 py-3 flex justify-between items-center">
          {/* Logo dan Toggle Sidebar */}
          <div className="flex items-center">
            <button
              data-drawer-target="drawer-navigation"
              data-drawer-toggle="drawer-navigation"
              aria-controls="drawer-navigation"
              className="p-2 mr-2 text-gray-600 rounded-lg cursor-pointer md:hidden hover:text-gray-900 hover:bg-gray-100 focus:ring-2 focus:ring-gray-100 dark:focus:ring-gray-700 dark:text-gray-400 dark:hover:bg-gray-700 dark:hover:text-white"
            >
              <svg
                aria-hidden="true"
                className="w-6 h-6"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path
                  fillRule="evenodd"
                  d="M3 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1zm0 5a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1z"
                  clipRule="evenodd"
                ></path>
              </svg>
            </button>

            <a href="/admin" className="flex items-center">
              <img
                src="https://flowbite.s3.amazonaws.com/logo.svg"
                className="h-8 mr-2"
                alt="Logo"
              />
              <span className="text-2xl font-semibold dark:text-white">
                AdminPanel
              </span>
            </a>
          </div>

          {/* Profil User */}
          <div className="flex items-center">
            <button
              type="button"
              className="flex items-center text-sm bg-gray-800 rounded-full focus:ring-2 focus:ring-gray-300 dark:focus:ring-gray-600"
            >
              <img
                className="w-8 h-8 rounded-full"
                src="https://flowbite.s3.amazonaws.com/blocks/marketing-ui/avatars/michael-gough.png"
                alt="user"
              />
            </button>
          </div>
        </div>
      </nav>

      {/* ======== Sidebar ======== */}
      <aside
        id="drawer-navigation"
        className="fixed top-0 left-0 z-40 w-64 h-screen pt-16 bg-white border-r border-gray-200 dark:bg-gray-800 dark:border-gray-700 transition-transform md:translate-x-0 -translate-x-full"
        aria-label="Sidebar"
      >
        <div className="h-full px-3 py-5 overflow-y-auto">
          <ul className="space-y-2 font-medium">
            <li>
              <Link
                to="/admin"
                className="flex items-center p-2 text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <svg
                  className="w-6 h-6 text-gray-500 dark:text-gray-400"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M2 10a8 8 0 018-8v8h8a8 8 0 11-16 0z"></path>
                  <path d="M12 2.252A8.014 8.014 0 0117.748 8H12V2.252z"></path>
                </svg>
                <span className="ml-3">Overview</span>
              </Link>
            </li>

            <li>
              <Link
                to="/admin/users"
                className="flex items-center p-2 text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <svg
                  className="w-6 h-6 text-gray-500 dark:text-gray-400"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z"></path>
                  <path
                    fillRule="evenodd"
                    d="M4 5a2 2 0 012-2 3 3 0 003 3h2a3 3 0 003-3 2 2 0 012 2v11a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4h.01a1 1 0 010 2H7a1 1 0 110-2z"
                    clipRule="evenodd"
                  ></path>
                </svg>
                <span className="ml-3">Users</span>
              </Link>
            </li>

            <li>
              <Link
                to="/admin/books"
                className="flex items-center p-2 text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <svg
                  className="w-6 h-6 text-gray-500 dark:text-gray-400"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path d="M4 5a2 2 0 012-2h8a2 2 0 012 2v10a1 1 0 01-1 1H6a2 2 0 01-2-2V5z" />
                </svg>
                <span className="ml-3">Books</span>
              </Link>
            </li>

            <li>
              <Link
                to="/admin/genres"
                className="flex items-center p-2 text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <svg
                  className="w-6 h-6 text-gray-500 dark:text-gray-400"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M17.707 9.293a1 1 0 010 1.414l-7 7a1 1 0 01-1.414 0l-7-7A.997.997 0 012 10V5a3 3 0 013-3h5c.256 0 .512.098.707.293l7 7zM5 6a1 1 0 100-2 1 1 0 000 2z"
                    clipRule="evenodd"
                  />
                </svg>
                <span className="ml-3">Genres</span>
              </Link>
            </li>

            <li>
              <Link
                to="/admin/authors"
                className="flex items-center p-2 text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <svg
                  className="w-6 h-6 text-gray-500 dark:text-gray-400"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"
                    clipRule="evenodd"
                  />
                </svg>
                <span className="ml-3">Authors</span>
              </Link>
            </li>

            <li>
              <Link
                to="/admin/transactions"
                className="flex items-center p-2 text-gray-900 rounded-lg dark:text-white hover:bg-gray-100 dark:hover:bg-gray-700"
              >
                <svg
                  className="w-6 h-6 text-gray-500 dark:text-gray-400"
                  fill="currentColor"
                  viewBox="0 0 20 20"
                >
                  <path
                    fillRule="evenodd"
                    d="M10 2a4 4 0 00-4 4v1H5a1 1 0 00-.994.89l-1 9A1 1 0 004 18h12a1 1 0 00.994-1.11l-1-9A1 1 0 0015 7h-1V6a4 4 0 00-4-4z"
                    clipRule="evenodd"
                  />
                </svg>
                <span className="ml-3">Transactions</span>
              </Link>
            </li>
          </ul>
        </div>
      </aside>

      {/* ======== Konten Utama ======== */}
      <main
        className="p-6 pt-20 md:ml-64 transition-all duration-300"
        style={{ marginLeft: "16rem" }} // 👈 paksa konten geser sejauh sidebar
      >
        <div className="border border-gray-300 dark:border-gray-600 rounded-xl p-6 bg-white dark:bg-gray-800 shadow-sm min-h-[calc(100vh-120px)]">
          <Outlet />
        </div>
      </main>
    </div>
  );
}
